create definer = root@localhost trigger update_schuld
    before UPDATE
    on financien
    for each row
    SET NEW.schuld = NEW.verschuldigd - NEW.overgemaakt;

